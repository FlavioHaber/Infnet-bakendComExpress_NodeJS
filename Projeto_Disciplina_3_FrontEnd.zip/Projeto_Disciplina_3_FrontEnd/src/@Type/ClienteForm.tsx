export type ClienteForm = {
    id: string;
    nome: string;
    endereco: string;
    bairro: string;
    cidade: string;
    estado: string;
}
