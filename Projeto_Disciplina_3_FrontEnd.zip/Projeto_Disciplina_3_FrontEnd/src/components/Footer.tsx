import styled from "@emotion/styled"
import { Typography } from "@mui/material";

const Footer = () => {
    return (
       <Footer.Container>
            <Typography variant="h6">
                Curso de Pós-Graduação Desenvolvedor Web Full-Stack - Segundo projeto em React - Infnet - 04/2023
            </Typography>
       </Footer.Container>
    )
}

Footer.Container = styled.footer`
    display: flex;
    justify-content: center;
    width: 100%;
    position: fixed;
    bottom: 0;
    padding: 10px;
    background-color: #1976d2;
    color: white;
`
export default Footer;
