import styled from "@emotion/styled";
import {AppBar, Toolbar} from "@mui/material";
const Header = () => {
    return (
        <AppBar position="static">
            <Toolbar>
                <Header.Menu>
                    <img src={require('../image/Icone.ico')}/>           
                </Header.Menu>
                <Header.Title>
                    <h3>Santa Cruz Indústria Gráfica Ltda.</h3>
                </Header.Title>
            </Toolbar>
        </AppBar>
    )
}

Header.Menu = styled.div`
    margin-right: 10px;
`
Header.Title = styled.div`
`
export default Header