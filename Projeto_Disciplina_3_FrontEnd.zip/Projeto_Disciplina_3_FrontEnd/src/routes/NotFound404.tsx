import { Card, CardContent, CardActions, Container } from "@mui/material";
import { Link } from "react-router-dom";
import EmotionIcon from '@mui/icons-material/SentimentVeryDissatisfied';
import styled from "@emotion/styled";

const NotFound404 = () => {
  return (
    <NotFound404.Container maxWidth="sm">
        <Card>
            <NotFound404.CardContent>
              <NotFound404.EmotionIcon />
              <h3> Atenção, página não encontrada.</h3>
              <h4> Verfique se a URL <strong>{window.location.href}</strong> está correta? </h4>          
            </NotFound404.CardContent>
            <CardActions>
                  <Link to={'/'}>Pagina inicial</Link>
            </CardActions>
        </Card>
    </NotFound404.Container>
    
  )
}

NotFound404.Container = styled(Container)`
  margin-top: 100px;  
  text-align: center;
`
NotFound404.CardContent = styled(CardContent)`
  font-size: 24px;
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
`
NotFound404.EmotionIcon = styled(EmotionIcon)`
  font-size: 90px;
`
export default NotFound404