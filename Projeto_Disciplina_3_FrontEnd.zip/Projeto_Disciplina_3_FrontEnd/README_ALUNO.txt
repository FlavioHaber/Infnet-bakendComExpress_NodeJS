Instituto Infnet - Pós-graduação Live
Curso: MIT em Desenvolvimento Full Stack
Classe: PGLLFS01C0-35-L1
Modalidade: Live
Disciplina: Front-end com React [23E1_3]
Professor: Alexandre Werneck Andreza
Aluno: Flávio José Braga Haber