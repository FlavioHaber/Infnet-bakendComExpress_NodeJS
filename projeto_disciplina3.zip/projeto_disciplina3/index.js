const express = require('express')
const cors = require('cors')
const app = express()

const usuarioRoutes = require('./routes/usuarioRoutes')

const host = '127.0.0.1'
const port = 3333

app.use(cors("http://localhost:3333/usuarios"))
app.use(express.json())
app.use('/usuarios', usuarioRoutes)


app.listen(port, host, ()=>{
    console.log(`Server running at http://${host}:${port}`)
})