const {Validator} = require('jsonschema')
const validator = new Validator()

const usuarioSchema ={
    type: "object", 
    properties: {
        id: {type: 'string'},
        nome: {type: 'string'},
        endereco: {type: 'string'},
        bairro: {type: 'string'},
        cidade: {type: 'string'},
        estado: {type: 'string'}
    },
    "required": ['nome', 'endereco', 'bairro', 'cidade', 'estado']
}

const validateDataUsuario = (e) => {
    return validator.validate(e, usuarioSchema)
}

module.exports = {validateDataUsuario}