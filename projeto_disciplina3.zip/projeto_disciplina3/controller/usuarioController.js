const {v4 : uuidv4} = require('uuid')
const {validateDataUsuario} = require('../model/usuarioModel')

const fs = require('fs')

//--------> GET
function getUsuariosPromise()
{
    return new Promise((resolve, reject) => {
        fs.readFile('../PROJETO_DISCIPLINA3/model/usuarios.json', 'utf8', (err, data) => {
            if (err) {
                reject(err)
            }
            else {
                let usuarios = JSON.parse(data)
                resolve(usuarios)
            }
        })

      }    
    )
}

const getUsuarios = (req, res) => {
    getUsuariosPromise()
    .then(usuarios => res.status(200).json(usuarios))
    .catch(err => res.status(500).send(err.message));
}

//--------> POST
function addUsuariosPromise(usuario)
{
    return new Promise((resolve, reject) => {
        fs.readFile('../projeto_disciplina3/model/usuarios.json', 'utf8', (err, data) => {
            if (err) {
                reject(err);
            }
            else {
                let usuarios = JSON.parse(data)

                const id = uuidv4()
                const usuarioNovo = {id, ...usuario}

                usuarios.push(usuarioNovo)

                fs.writeFile('../projeto_disciplina3/model/usuarios.json', JSON.stringify(usuarios), (err) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(usuarioNovo);
                    }
                })
            }
        })       
    })
}

const addUsuarios = (req, res) => {
    const usuario = req.body
    
    const validResult = validateDataUsuario(usuario)

    if (!validResult.valid)
    {
        return res.status(400).json({message:'Dados do usuário inválido', errors : validResult.errors})
    }

    addUsuariosPromise(usuario)
    .then(usuarioNovo => res.status(200).json(usuarioNovo))
    .catch(err => res.status(500).send(err.message))
}

//--------> PUT
function updateUsuariosPromise(id, usuario)
{
    return new Promise((resolve, reject) => {
        fs.readFile('../projeto_disciplina3/model/usuarios.json', 'utf8', (err, data) => {
            if (err) {
                reject(err)
            } 
            else {
                let usuarios = JSON.parse(data)  

                const index = usuarios.findIndex((e)=> e.id === id)

                if (index === -1) {
                    reject(new Error('Usuário não encontrado'))
                }
                else {
                    const usuarioUpdate = {...usuarios[index], ...usuario}

                    usuarios[index] = usuarioUpdate

                    fs.writeFile('../projeto_disciplina3/model/usuarios.json', JSON.stringify(usuarios), (err) => {
                        if (err) {
                            reject(err)
                        } else {
                            resolve(usuarioUpdate)
                        }
                    })
                }

            }
        })
    })
}

const updateUsuarios = (req, res) => {
    const id = req.params.id
    const usuario = req.body
    updateUsuariosPromise(id, usuario)
    .then(usuarioUpdate => res.status(200).json(usuarioUpdate))
    .catch(err => res.status(500).send(err.message))
}


//--------> DELETE

function removeUsuariosPromise(id)
{
    return new Promise((resolve, reject) => {
        fs.readFile('../projeto_disciplina3/model/usuarios.json', 'utf8',(err, data) => {
            if (err) {
                reject(err)
            } else {
                const usuarios = JSON.parse(data)

                const index = usuarios.findIndex((e) => e.id === id)

                if (index === -1) {
                    reject(new Error('Usuário não encontrado'))
                } else {
                    usuarios.splice(index, 1)

                    fs.writeFile('../projeto_disciplina3/model/usuarios.json', JSON.stringify(usuarios), err => {
                        if (err) {
                            reject(err)
                        } else {
                            resolve()
                        }
                    })
                }
            }
        })
    })
}

const removeUsuarios = (req, res) => {
    const id = req.params.id
    removeUsuariosPromise(id)
    .then(() => res.status(200).json({message: "Usuário Deletado"}))
    .catch(err => res.status(500).send(err.message))
}

module.exports = {getUsuarios, addUsuarios, updateUsuarios, removeUsuarios}